<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Focus Carelink</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js" type="text/javascript"></script>
<script src="layout_inc/jquery.cookie.js" type="text/javascript"></script>
<script title="fontsize" src="layout_inc/fontsize.js" type="text/javascript"></script>
    <script src="layout_inc/jquery.cycle.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#slides').cycle();
    });
    </script>


</head>
<body class="website-background" id="navhome-page">
	<header id="header">
		<div class="width">
			<a href="index.php" class="logo"><img src="layout/logo.png" alt="Logo" title="Logo" /></a>
			<nav>
				<ul class="navigation">
					<li><a href="index.php" id="navhome-link">Home</a></li><li><a href="page.php?id=1" id="nav1-link">About Us</a></li><li><a href="page.php?id=34" id="nav34-link">Legal</a></li><li><a href="page.php?id=2" id="nav2-link">What we do</a></li><li><a href="page.php?id=3" id="nav3-link">Who we help</a></li><li><a href="page.php?id=11">Careers</a></li><li><a href="contact.php" id="navcontact-link">Contact</a></li>
				</ul>
			</nav>
			<div class="options">
				<a href="javascript:void(0);" class="font-size"></a>
                          			<a href="staff/" class="staff-login">Staff Login &raquo;</a>
			   	    
				
				<br class="clear" />
			</div>
			<br class="clear" />
		</div>
	</header>
	<div id="container">
		<div class="width">
        
            <div id="slides">
                <div id="slide2"></div> <!-- where you feel secure -->
                <div id="slide3"></div> <!-- where you can be yourself -->
            	<div id="slide1"></div> <!-- where you feel cared for -->
                <!-- <div id="slide4"></div> --> <!-- where you are in control -->
                <div id="slide5"></div> <!-- where you have freedom-->
                <div id="slide6"></div> <!-- where we focus -->
            </div>

			<br class="clear" />
		</div>
    </div>
    
	</div>
	<footer id="footer" style="width: 100%; overflow: hidden;">
   	  <div class="width">
			<div class="bottom-nav">
				<a href="#" id="item1"></a>
				<a href="page.php?id=3" id="item2">Who We Help &raquo;</a>
				<a href="page.php?id=4" id="item3">Personal Home Care &raquo;</a>
				<a href="page.php?id=5" id="item4">Live-In Care &raquo;</a>
				<a href="page.php?id=6" id="item5">Domestic &amp; Shopping &raquo;</a>
		 		<a href="page.php?id=7" id="item6">Cultural &amp; Social Services &raquo;</a>
				<a href="#" id="item7"></a>
			</div>
   	  </div>
		<div class="statement">
			<p>We provide quality domiciliary care support within service users homes, appropriately tailored to our clients needs to enhance their quality of life and enable them to participate in their communities.</p>
		</div>
	   	<div class="width copyrights">
			<span class="phone">020 7419 7419</span> <span class="address">121 St Pancras Way, Camden, London, NW1 0RD</span>
			<div class="float_right"><span class="phone">&nbsp;</span><span class="copyright">Copyright &copy; Focus Carelink, 2012</span> - <span class="credits">website lovingly created by <a href="#" class="piddy"><img src="layout/piddy.png" alt="piddy" title="piddy.co.uk" /></a></span></div>
		</div>
	</footer>
</body>
</html>


