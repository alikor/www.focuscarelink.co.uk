<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Focus Carelink</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js" type="text/javascript"></script>
<!--
    <link rel="stylesheet" href="../models/sceditor/minified/themes/default.min.css" type="text/css" media="all" />
    <script type="text/javascript" src="../models/sceditor/minified/jquery.sceditor.min.js"></script>
    <script>
        $(document).ready(function() {
            $("textarea").sceditor({
                style: "minified/jquery.sceditor.default.min.css"
            });
        });
    </script>

-->

    <script type="text/javascript" src="../layout_inc/ckeditor/ckeditor.js"></script>
</head>
<body>
	<header id="header">
		<div class="width">
			<a href="index.php" class="logo"><img src="../layout/logo.png" alt="Logo" title="Logo" /></a>
			
			<div class="options">
				
		           <a href="forgot-password.php">Forgot Password</a>
                       <a href="http://focuscarelink.co.uk/">&laquo; Back to Site</a>
                   	    			</div>
			<br class="clear" />
		</div>
	</header>
    
    	<div id="container">
		<div class="width">
        	
			<table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">
				<form name="newUser" action="/staff/login.php" method="post">

					<tr>
						<td colspan="3">
							<h1>Login</h1>
							 
						</td>
						<td rowspan="4" valign="top" align="right"><img src="layout_inc/login.png" /></td>
					</tr>

					<tr>
						<td width="100">Username</td>
						<td width="200"><input type="text" name="username" /></td>
						<td width="150"></td>
					</tr>

					<tr>
						<td>Password</td>
						<td><input type="password" name="password" /></td>
						<td><a href="forgot-password.php">Forgot password?</a></td>
					</tr>

					<tr>
						<td></td>
						<td><input type="submit" value="Login" class="submit" /></td>
						<td></td>
					</tr>

				</form>
			</table>

        </div>

			<br class="clear" />
		</div>
    </div>
    
	</div>
	<footer id="footer" style="width: 100%; overflow: hidden;">
	   	<div class="width copyrights">
			<div class="float_right"><span class="phone">&nbsp;</span><span class="copyright">Copyright &copy; Focus Carelink, 2012</span> - <span class="credits">website lovingly created by <a href="#" class="piddy"><img src="../layout/piddy.png" alt="piddy" title="piddy.co.uk" /></a></span></div>
            <br class="clear" />
		</div>
	</footer>
</body>
</html>
