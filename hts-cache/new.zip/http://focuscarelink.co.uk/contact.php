
<style type="text/css">
.manage p {
	margin-top: 10px;
	line-height: 150%;
}
</style>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Focus Carelink</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js" type="text/javascript"></script>
<script src="layout_inc/jquery.cookie.js" type="text/javascript"></script>
<script title="fontsize" src="layout_inc/fontsize.js" type="text/javascript"></script>


</head>
<body class="website-background" id="navcontact-page">
	<header id="header">
		<div class="width">
			<a href="index.php" class="logo"><img src="layout/logo.png" alt="Logo" title="Logo" /></a>
			<nav>
				<ul class="navigation">
					<li><a href="index.php" id="navhome-link">Home</a></li><li><a href="page.php?id=1" id="nav1-link">About Us</a></li><li><a href="page.php?id=34" id="nav34-link">Legal</a></li><li><a href="page.php?id=2" id="nav2-link">What we do</a></li><li><a href="page.php?id=3" id="nav3-link">Who we help</a></li><li><a href="page.php?id=11">Careers</a></li><li><a href="contact.php" id="navcontact-link">Contact</a></li>
				</ul>
			</nav>
			<div class="options">
				<a href="javascript:void(0);" class="font-size"></a>
                          			<a href="staff/" class="staff-login">Staff Login &raquo;</a>
			   	    
				
				<br class="clear" />
			</div>
			<br class="clear" />
		</div>
	</header>
	<div id="container">
		<div class="width">
                
        <div class="page-content">

            <h2>Contact Us</h2>

			
            <table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">
				
				<tr>

					<td width="50%" valign="top">

							<p>Contact us by email at <a href="mailto:admin@focuscarelink.co.uk">admin@focuscarelink.co.uk<a>.</p>

							<table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">
								<tr>
									<td><span style="font-weight: bold; color: #222;">Focus Care Link Camden</span><p>248 Kentish Town Road<br />
London<br />
NW5&nbsp;2AB</p>
</td>
								</tr>
								<tr>
									<td>020 7419 7419</td>
								</tr>
								<tr>
									<td><strong>Find us on <a href="https://maps.google.co.uk/?ie=UTF8&amp;q=Focus Care Link, First Floor, 248 Kentish Town Road, London, NW5 2AB&amp;t=m&amp;z=15&amp;iwloc=near">Google Maps</a>.</strong></td>
								</tr>
							</table>

							<br />

							<table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">
								<tr>
									<td><span style="font-weight: bold; color: #222;">Focus Care Link Tower Hamlets</span><p>Closed.</p>
</td>
								</tr>
								<tr>
									<td></td>
								</tr>
								<tr>
									<td><strong>Find us on <a href="https://maps.google.co.uk/?ie=UTF8&amp;q=Limehouse%20Court%203-11%20Dod%20Street%20E14%207EQ&amp;t=m&amp;z=15&amp;iwloc=near">Google Maps</a>.</strong></td>
								</tr>
							</table>

							<br />

							<table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">
								<tr>
									<td><span style="font-weight: bold; color: #222;">Focus Care Link Waltham Forest</span><p>Gateway&nbsp;Business Centre<br />
Suite 20, 210 Church Road<br />
Leyton<br />
E10 7JQ</p>
</td>
								</tr>
								<tr>
									<td>020 8189 5986</td>
								</tr>
								<tr>
									<td><strong>Find us on <a href="https://maps.google.co.uk/?ie=UTF8&amp;q=Focus Care Link, Gateway Business Centre, 210 Church Road, E10 7JQ&amp;t=m&amp;z=15&amp;iwloc=near">Google Maps</a>.</strong></td>
								</tr>
							</table>

					</td>

					<td valign="top">

						<table border="0" cellpadding="4" cellspacing="0" width="100%" class="manage">

							<form name="editSettings" action="/contact.php" method="post">
								<tr>
									<td width="20%">Nature of Enquiry</td>
									<td width="80%">
										<select name="nature" style="width: 80%">
											<option value="0">Please select...</option>
											<option value="1">I want to know more about your care services</option>
											<option value="2">I am interested in a care worker job</option>
											<option value="3">I am interested in an office job</option>
										</select>
									</td>
								</tr>

								<tr>
									<td width="20%">Name</td>
									<td width="80%"><input type="text" name="name" value="" style="width: 80%;" /></td>
								</tr>

								<tr>
									<td>Email</td>
									<td><input type="text" name="email" value="" style="width: 80%;" /></td>
								</tr>

								<tr>
									<td>Post Code</td>
									<td><input type="text" name="postcode" value="" style="width: 80%;" /></td>
								</tr>

								<tr>
									<td>Contact Number</td>
									<td><input type="text" name="number" value="" style="width: 80%;" /></td>
								</tr>

								<tr>
									<td valign="top">Message</td>
									<td><textarea name="content" style="width: 80%; height: 200px;"></textarea></td>
								</tr>

								<tr>
									<td></td>
									<td><input type="submit" value="Send message" /></td>
								</tr>

							</form>
								<tr>
									<td colspan="2"><br />
										If you would like to see our CQC rating, click <a target="_blank" href="http://www.cqc.org.uk/search/all/focus%20care%20link?location=nw1%200rd">here</a>.
									</td>
								</tr>


						</table>

					</td>

				</tr>

			</table>

        </div>
            
			<br class="clear" />
		</div>
    </div>
    
	</div>
	<footer id="footer" style="width: 100%; overflow: hidden;">
   	  <div class="width">
			<div class="bottom-nav">
				<a href="#" id="item1"></a>
				<a href="page.php?id=3" id="item2">Who We Help &raquo;</a>
				<a href="page.php?id=4" id="item3">Personal Home Care &raquo;</a>
				<a href="page.php?id=5" id="item4">Live-In Care &raquo;</a>
				<a href="page.php?id=6" id="item5">Domestic &amp; Shopping &raquo;</a>
		 		<a href="page.php?id=7" id="item6">Cultural &amp; Social Services &raquo;</a>
				<a href="#" id="item7"></a>
			</div>
   	  </div>
		<div class="statement">
			<p>We provide quality domiciliary care support within service users homes, appropriately tailored to our clients needs to enhance their quality of life and enable them to participate in their communities.</p>
		</div>
	   	<div class="width copyrights">
			<span class="phone">020 7419 7419</span> <span class="address">121 St Pancras Way, Camden, London, NW1 0RD</span>
			<div class="float_right"><span class="phone">&nbsp;</span><span class="copyright">Copyright &copy; Focus Carelink, 2012</span> - <span class="credits">website lovingly created by <a href="#" class="piddy"><img src="layout/piddy.png" alt="piddy" title="piddy.co.uk" /></a></span></div>
		</div>
	</footer>
</body>
</html>
